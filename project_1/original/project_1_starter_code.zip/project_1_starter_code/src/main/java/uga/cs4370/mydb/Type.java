package uga.cs4370.mydb;

/**
 * Representation of the possible types.
 */
public enum Type {
    INTEGER,
    DOUBLE,
    STRING
}
